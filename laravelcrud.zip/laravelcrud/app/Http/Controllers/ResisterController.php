<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;


class ResisterController extends Controller
{

    public function register()
    {
        return view('register');
    }

    public function res_submit(Request $request)
    {
        // dd($request)
;        $userdata = [

            $file = $request->file('file'),
            // dd($file),
            // $destinationPath = 'uploads/',
            $filename= $file->getClientOriginalName(),
            $file->move(public_path('/uploads'),$filename),

            'product_id' => $request->product_id,
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash:: make($request->password),
            'price' => $request->price,
            'status' => $request->radio,
            'image' => $filename,
        ];
            User::create($userdata);

        return redirect()->to('/register')->with('success', " Data Successfully added");
    }
}
