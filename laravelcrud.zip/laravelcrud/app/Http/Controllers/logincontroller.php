<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;



class logincontroller extends Controller
{
    public function login()
    {
        return view('login');
    }
    public function loginsubmit(Request $request)
    {
        $data = [
            'email' => $request->email,
            'password'=>$request->password
        ];
        if (Auth::attempt($data)) {
            return redirect('/tableshow')->with('success','Login successfully');

        }else {
            echo"Authentication not successful..";
            return redirect('/login ')->with('success','login not successfully');
        }
    }

    public function tableshow(Request $request)

     {

        // $uid = Auth::user()->id;
        $maindata = User::get();

        //  dd($maindata);
        // load the view and pass the sharks
        return view("tablesshow")->with(compact('maindata'));

    }
    public function destroy($id){

        $res=User::find($id)->delete();
         return  redirect()->back();
    }

    public function editshow($id)
    {
        $editdata = User::where('id',$id )->first();
    //    dd($editdata);

        return view('edit', ['data' => $editdata]);

    }

    public function update(Request $request, $id){
        $filename = "";
        if($request->hasFile('image')) {
            $file = $request->file('image');
            // $destinationPath = 'uploads/',
            $filename= $file->getClientOriginalName();
            $file->move(public_path('/uploads'),$filename);
        }
        $post = User::find($id);

        $post->id = $id;
        $post->product_id = $request->product_id;
        $post->name = $request->name;
        $post->email = $request->email;
        $post->password = $request->password;
        $post->price = $request->price;
        $post->status = $request->radio;
        // dd($request->radio);
        if($filename != "") {
        $post->image =$filename;
        }
    $post->save();

        return redirect('/tableshow')->with('success','data update successfully');

    }


}
