<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;


class DeleteController extends Controller
{
    public function destroy($id){

        $res=page::find($id)->delete();
        if ($res){
          $data=[

          'delete'=>'1',
          'msg'=>'success'
        ];
        }else{
          $data=[
          'delete'=>'0',
          'msg'=>'fail'
        ];
         }
         return  redirect()->back();
    }

    public function deleteAll(Request $request)
{

    // dd($request->all())  ;
    User::whereIn('id',explode(",",$request->deleteid))->delete();
    // User::where('id', $request->deleteid)->delete();
    return response()->json(['success'=>"Data Deleted successfully."]);
}

}
