<?php

use Illuminate\Support\Facades\Route;


use App\Http\Controllers\logincontroller;

use App\Http\Controllers\ResisterController;

use App\Http\Controllers\LogoutController;
use App\Http\Controllers\DeleteController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/login',[logincontroller::class, 'login'])->name('login');

Route::post('/login/submit',[logincontroller::class, 'loginsubmit']);

Route::get('/register',[ResisterController::class, 'register']);

Route::post('/register/submit',[ResisterController::class, 'res_submit']);




Route::middleware(['auth'])->group(function () {

Route::get('/tableshow',[logincontroller::class, 'tableshow']);

Route::delete('/delete/{id}', [logincontroller::class, 'destroy']);

Route::get('/logout', [LogoutController::class, 'logout']);

Route::post('/sharksDeleteAll',[DeleteController::class, 'deleteAll']);

Route::get('/editform/{id}', [logincontroller::class, 'editshow']);

Route::post('/editform/update/{id}', [logincontroller::class, 'update']);



});

