<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <div class="container-fluid p-5" id="page2">
            <h3>Information List</h3>
            <?php if(session('success')): ?>
            <div class="alert alert-success">
            <?php echo session('success'); ?>

            </div>
        <?php endif; ?>
            <button href="/sharksDeleteAll" class="btn btn-danger btn-sm" id="Multidelete" >Multi Delete</button>

             <a href="/logout" class="btn btn-primary btn-sm" >Logout</a>

            <table class="table" id="datatable"  cellspacing="0" cellpadding="3"  width="100%">
                <thead class="tablehead">
                    <tr>
                        <th width="50px"><input type="checkbox" id="master"></th>
                        <th scope="col">Id</th>
                        <th scope="col">Product_id </th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Price</th>
                        <th scope="col">Status</th>
                        <th scope="col">Image</th>
                    </tr>
                </thead>
                <tbody>



                    <?php $__currentLoopData = $maindata->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     <tr>
                            <td><input type="checkbox" class="sub_chk" data-id="<?php echo e($item->id); ?>"></td>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->product_id); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td><?php echo e($item->price); ?></td>
                        <td><?php echo e($item->status); ?></td>
                        <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
                         <td><img width="100px" height="100px" src="<?php echo e(url("/uploads")); ?>/<?php echo e($item->image); ?>"></td>
                        <td>
                            <form action="/delete/<?php echo e($item->id); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button  class='deletee btn btn-primary btn-sm'>Delete</button>
                            </form>
                            <a href="/editform/<?php echo e($item->id); ?>" class='edit1 btn btn-primary btn-sm'>Edit</a>
                        </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>

        </div>


        <script>

            $(document).ready(function () {

                $('#master').click(function () {
                $(':checkbox.sub_chk').prop('checked', this.checked);
               });
                   $('#Multidelete').on('click', function(e) {
                  var allVals = [];
                  $(".sub_chk:checked").each(function() {
                      allVals.push($(this).attr('data-id'));
                    });





                    if(allVals.length <=0)
                    {
                    //   alert(allVals.length);
                      swal("Please select row.");
                  }  else {

                      // var check = swal("Are you sure you want to delete this row?");
                      var id = $(this).data('id');

                      swal({
                          title: 'Are you sure?',
                          text: "You won't be able to Delete  this! data",
                          icon: 'warning',
                          buttons: true,
                          dangerMode: true,
                              }).then(function (click) {
                                   if(click) {

                                       var join_selected_values = allVals.join(",");

                                       $.ajax({
                                        //  alert(join_selected_values);

                                      url: '/sharksDeleteAll',
                                      type: 'POST',
                                      data: {_token: $('#token').val(), deleteid: join_selected_values},


                                      success: function (data) {

                                              if(data['success'] != ""){
                                                  swal(
                                                      'Delete!',
                                                      'Your Data Delete Successfully!',
                                                      'success'
                                                      )
                                              }


                                      }

                                  });


                                  } else {
                                      swal(
                                            'Cancel!',
                                            'success'
                                            )
                                  }

                              })


                  }
              });


              // $('[data-toggle=confirmation]').confirmation({
              //     rootSelector: '[data-toggle=confirmation]',
              //     onConfirm: function (event, element) {
              //         element.trigger('confirm');
              //     }
              // });

              $(document).on('confirm', function (e) {
                  var eele = e.target;
                  e.preventDefault();

                  $.ajax({
                      url: eele.href,
                      type: 'DELETE',
                      headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                      success: function (data) {
                          if (data['success']) {
                              $("#" + data['tr']).slideUp("slow");
                              alert(data['success']);
                          } else if (data['error']) {
                              alert(data['error']);
                          } else {
                              alert('Whoops Something went wrong!!');
                          }
                      },
                      error: function (data) {
                          alert(data.responseText);
                      }
                  });

                  return false;
              });
          });
      </script>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\laravelcrud\resources\views/tablesshow.blade.php ENDPATH**/ ?>