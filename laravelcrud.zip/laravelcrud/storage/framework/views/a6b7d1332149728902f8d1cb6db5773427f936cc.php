<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;


<style>
.error{
    color: red;
}
#page1{
    background-color: rgb(180, 228, 212);
}

</style>

    <div class="container pt-5 pb-5" id="page1" style="border: 3px solid black">
        <h1>Register</h1>
        <?php if(session('success')): ?>
        <div class="alert alert-success">
        <?php echo session('success'); ?>

        </div>
    <?php endif; ?>

        <form id="form" enctype='multipart/form-data' method="POST" action="/editform/update/<?php echo e($data->id); ?>" class="pt-5">
            <?php echo csrf_field(); ?>
                <!-- prouct_id -->
            <div class="col-lg-12">
                <div class=" row form-group ">
                    <div class="col-lg-2">
                        <label for="name">Product_id:</label>
                    </div>
                    <div class="col-lg-6">
                        <input type="number" class="form-control" value="<?php echo e($data->product_id); ?>" id="product_id" placeholder="Enter product_id" name="product_id">
                    </div>
                    <div class="col-lg-2">
                        <span class="error">*</span>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-12 pt-3">
                <div class=" row form-group ">
                    <div class="col-lg-2">
                        <label for="name">Name :</label>
                    </div>
                    <div class="col-lg-6">
                        <input type="text" class="form-control" value="<?php echo e($data->name); ?>" id="name" placeholder="Enter Name" name="name" id="name">
                        <input type="hidden" id="id" name="id" value="">
                    </div>
                    <div class="col-lg-2">
                        <span class="error">*</span>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-12 pt-3">
                <div class=" row form-group ">
                    <div class="col-lg-2">
                        <label for="name">Email  :</label>
                    </div>
                    <div class="col-lg-6">
                        <input type="email" class="form-control" value="<?php echo e($data->email); ?>" id="email" placeholder="Enter email" name="email" id="email">
                    </div>
                    <div class="col-lg-2">
                        <span class="error">*</span>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-12 pt-3">
                <div class=" row form-group ">
                    <div class="col-lg-2">
                        <label for="name">Password  :</label>
                    </div>
                    <div class="col-lg-6">
                        <input type="password" class="form-control" value="<?php echo e($data->password); ?>" id="password" placeholder="Enter password" name="password" id="password">
                    </div>
                    <div class="col-lg-2">
                        <span class="error">*</span>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-12 pt-3">
                <div class=" row form-group ">
                    <div class="col-lg-2">
                        <label for="name">Price :</label>
                    </div>
                    <div class="col-lg-6">
                        <input type="number" class="form-control" value="<?php echo e($data->price); ?>" id="price" placeholder="Enter Price" name="price">
                    </div>
                    <div class="col-lg-2">
                        <span class="error">*</span>
                    </div>
                </div>
            </div>

                       <!-- image -->
            <div class="col-lg-12 pt-3">
                <div class=" row form-group ">
                    <div class="col-lg-2">
                        <label for="name">Image  :</label>
                    </div>
                    <div class="col-lg-6">
                        <input type="file" class="form-control" id="file" name="file" >
                    <img width="100px" height="100px" src="<?php echo e(url("/uploads")); ?>/<?php echo e($data->image); ?>" >

                    </div>
                </div>
            </div>

            <div class="col-lg-12 pt-3">
                <div class="form-group row ">
                    <div class="col-lg-2">
                        <label for="name">Status : </label>
                    </div>
                    <div class="col-lg-10">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input radio" type="radio" name="radio" id="Radio1" value="0" <?php echo e(($data->status=="0")? "checked" : ""); ?>>
                            <label class="form-check-label" for="user">0</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input radio" type="radio" name="radio" id="Radio2" value="1" <?php echo e(($data->status=="1")? "checked" : ""); ?>>
                            <label class="form-check-label" for="inlineRadio2">1</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12 pt-3">
                <div class="row">
                    <div class="col-lg-2">
                        <button type="submit" id="submit" class="btn btn-primary">Update</button>
                    </div>
                    <div class="col-lg-2">
                        <a href="/login" id="login" class="btn btn-primary">Login</a>
                    </div>
                </div>
            </div>



        </form>
    </div>




<?php /**PATH C:\xampp\htdocs\laravelcrud\resources\views/edit.blade.php ENDPATH**/ ?>