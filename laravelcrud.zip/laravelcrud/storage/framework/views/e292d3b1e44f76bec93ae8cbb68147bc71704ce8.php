</body>
</html><?php /**PATH C:\xampp\htdocs\laravelcrud\resources\views/footer.blade.php ENDPATH**/ ?>